

// Una variable es un espacio que guardamos en memoria, que es eso?
// yo tengo un vaso y que tengo que hacer para que se convierta en variable? guardar algo
// dentro y llamo a lo que lleva dentro papel y el vaso recipiente
// esto se escribiria recipiente="papel"
// esto se llama variable porque puede cambiar, puedes sacar el papel y meterle un boli.
// dentro de la variable tenemos el string que es una cadena de texto, number, booleano.
//CASOS ESPECIALES DE DATOS: undefined (significa que el valor existe pero no esta definido)
// , null (significa que el valor que tiene es vacio), nan(no es un numero, suele darse cuando el resultado de alguna operacion tiene que ser numero)-
// La variable se puede declarar con var, let, const;
// let tiene menos alcance, var alcance global, las variables const se definen una vez
//  y ya no mas.
// yo digo let numero y para inicializarla necesito darle valor let numero = 29;
// puedo iniciarla abajo llamando a numero = 29 y el valor.
// a una variable const hay que declararla e inicializarla siempre. 
// punto y coma siempre.
// prompt("Hola rancio"): sale una alerta en la que hay que responder a hola rancio.
// prompt es una funcion y donde se guarda? en una variable, que seria: 
// let nombre = prompt("decime tu nombre"); si yo despues pongo alert(nombre) el resultado
// es el nombre que yo rellene, belen por ejemplo. 
// 





// alert("Hola Mundo");
let producto = "nombre del producto";
let disponible;

disponible = true;

disponible = "no hay producto";

let camiseta = "red",
pantalon = "yellow",
zapatos;

console.log("comentario Camiseta:", camiseta);

zapatos = "negros";

console.log("comentario pantalon", pantalon);
console.log("comentario Zapatos", zapatos);

const constante = "valor constante";
console.log("constante:", constante);
